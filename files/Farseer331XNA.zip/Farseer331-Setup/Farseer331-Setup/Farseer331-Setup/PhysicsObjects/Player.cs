﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FarseerPhysics.Dynamics;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using FarseerPhysics.Factories;
using Farseer331_Setup.Helpers;
using FarseerPhysics.Dynamics.Joints;

namespace Farseer331_Setup.PhysicsObjects
{
    public class Player
    {
        private DrawablePhysicsObject torso;
        private DrawablePhysicsObject wheel;
        private RevoluteJoint axis;

        private DateTime previousJump;                  // time at which we previously jumped
        private const float jumpInterval = 1.0f;        // in seconds
        private Vector2 jumpForce = new Vector2(0, -1); // applied force when jumping
        private const float speed = 3.0f;               // wheel rotations per second when moving

        /// <summary>
        /// Creates a controlable player
        /// </summary>        
        public Player(World world, Texture2D torsoTexture, Texture2D wheelTexture, Vector2 size, float mass, Vector2 startPosition)
        {
            // Because the player is a composition of two bodies we first need
            // to calculate the sizes of the individual bodies
            Vector2 torsoSize = new Vector2(size.X, size.Y - size.X / 2.0f);
            float wheelSize = size.X;

            // Create the torso which
            torso = new DrawablePhysicsObject(world, torsoTexture, torsoSize, mass / 2.0f);
            torso.Position = startPosition;            
                        
            // Create the feet of the body, here implemented as high friction wheels 
            wheel = new DrawablePhysicsObject(world, wheelTexture, wheelSize, mass / 2.0f);
            wheel.Position = torso.Position + new Vector2(0, torsoSize.Y / 2.0f);
            wheel.Body.Friction = 0.8f;

            // Create a joint to keep the torso upright
            JointFactory.CreateFixedAngleJoint(world, torso.Body);

            // Connect the feet to the torso
            axis = JointFactory.CreateRevoluteJoint(world, torso.Body, wheel.Body, Vector2.Zero);
            axis.CollideConnected = false;
            
            axis.MotorEnabled = true;
            axis.MotorSpeed = 0;
            axis.MotorTorque = 3;
            axis.MaxMotorTorque = 10;

            previousJump = DateTime.Now;
        }

        public void Move(Movement movement)
        {
            switch(movement)
            {
                case Movement.Left:
                    axis.MotorSpeed = -MathHelper.TwoPi * speed;
                    break;

                case Movement.Right:
                    axis.MotorSpeed = MathHelper.TwoPi * speed;
                    break;

                case Movement.Stop:                    
                    axis.MotorSpeed = 0;
                    break;
            }
        }


        public void Jump()
        {
            if ((DateTime.Now - previousJump).TotalSeconds >= jumpInterval)
            {
                torso.Body.ApplyLinearImpulse(ref jumpForce);
                previousJump = DateTime.Now;
            }
        }


        public void Draw(SpriteBatch spriteBatch)
        {
            torso.Draw(spriteBatch);
            wheel.Draw(spriteBatch);
        }
    }

    public enum Movement
    {
        Left,
        Right,
        Stop
    }
}
