﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

// Loosely inspired on http://msdn.microsoft.com/en-us/library/bew39x2a.aspx

namespace AsynchronousSockets
{
    class Program
    {
        static readonly IPAddress serverIP = IPAddress.Loopback;
        const int serverPort = 2500;

        static ManualResetEvent connectDone = new ManualResetEvent(false);
        static ManualResetEvent sendDone = new ManualResetEvent(false);


        static void Main(string[] args)
        {
            Console.Out.WriteLine("This is the client");
            Console.Out.WriteLine("Write the message to send. End with an emtpy line to start the transmisison. \n");

            string message = String.Empty;
            string line = String.Empty;
            while((line = Console.ReadLine()) != "")
            {
                message += line + Environment.NewLine;
            }

            Console.Out.WriteLine("Sending message: \n");
            Console.Out.Write(message);
            Console.Out.Write("\n");

            SendMessageAsync(message);            

            Console.Read();
        }

        static void SendMessageAsync(string message)
        {                        
            // Initiate connecting to the server
            Socket connection = Connect();

            // block this thread until we have connected
            // normally your program would just continue doing other work
            // but we've got nothing to do :)
            connectDone.WaitOne();
            Console.Out.WriteLine("Connected to server");

            // Start sending the data
            SendData(connection, message);
            sendDone.WaitOne();
            Console.Out.WriteLine("Message successfully sent");
        }        

        static Socket Connect()
        {
            try
            {             
                IPEndPoint serverAddress = new IPEndPoint(serverIP, serverPort);
                Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                client.BeginConnect(serverAddress, new AsyncCallback(ConnectCallback), client);

                return client;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

                return null;               
            }
        }

        static void SendData(Socket connection, string message)
        {
            try
            {
                byte[] data = Encoding.UTF8.GetBytes(message);

                // We store how much data the server should expect
                // in the first 4 bytes of the data we're going to send
                byte[] head = BitConverter.GetBytes(data.Length);

                byte[] total = new byte[data.Length + head.Length];
                head.CopyTo(total, 0);
                data.CopyTo(total, head.Length);

                connection.BeginSend(total, 0, total.Length, 0, new AsyncCallback(SendCallBack), connection);
            }
            catch (Exception e)
            {
                Console.Out.WriteLine(e.Message);
            }
        }

        private static void ConnectCallback(IAsyncResult ar)
        {
            try
            {
                Socket client = (Socket)ar.AsyncState;
                client.EndConnect(ar);
                connectDone.Set();
            }
            catch (Exception e)
            {
                Console.Out.WriteLine(e.Message);
            }
        }

        private static void SendCallBack(IAsyncResult ar)
        {
            try
            {
                Socket client = (Socket)ar.AsyncState;
                int bytes = client.EndSend(ar);

                Console.Out.WriteLine("A total of {0} bytes were sent to the server", bytes);

                sendDone.Set();
            }
            catch (Exception e)
            {
                Console.Out.WriteLine(e.Message);
            }
        }
    }
}
