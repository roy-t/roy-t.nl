﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Media;

namespace MimboWPF
{
    public class RobotFace
    {
        public double maxIrisMovement = 20;
        public double maxBrowMovement = 50;
        public double maxMouthMovement = 60;

        private Vector[] irisNeutral;        
        private double browNeutral;
        private Rect mouthNeutral;        

        private int browMemory = 7;
        private List<double> browHistory;
        private Rectangle[] brow;

        private int mouthMemory = 7;
        private List<Vector3> mouthHistory;        
        private Ellipse mouth2;

        private int irisMemory = 7;
        private List<Vector> irisHistory;
        private Ellipse[] iris;    

        public RobotFace(Ellipse leftIris, Ellipse rightIris, Rectangle leftBrow, Rectangle rightBrow, Ellipse mouth, int smoothing)
        {
            browMemory = smoothing;
            irisMemory = smoothing;
            mouthMemory = smoothing;

            this.iris = new Ellipse[] { leftIris, rightIris };
            this.brow = new Rectangle[] { leftBrow, rightBrow };            
            this.mouth2 = mouth;

            irisNeutral = new Vector[]
            {
                new Vector(Canvas.GetLeft(leftIris), Canvas.GetTop(leftIris)),
                new Vector(Canvas.GetLeft(rightIris), Canvas.GetTop(rightIris))
            };
            
            browNeutral = Canvas.GetTop(leftBrow);
            
            mouthNeutral = new Rect(Canvas.GetLeft(mouth), Canvas.GetTop(mouth), mouth.Width, mouth.Height);

            irisHistory = new List<Vector>();
            browHistory = new List<double>();
            mouthHistory = new List<Vector3>();
        }

        private double Lerp(double a, double b, double mul)
        {
            if (a <= b)
            {
                return a + (b - a) * mul;
            }
            else
                return Lerp(b, a, mul);
        }

        // All offsets are in the [-1,1] range

        public void Look(Vector offsetLeft, Vector offsetRight)
        {
            Vector position = new Vector();
            Vector offset = new Vector();

            offset.X = (offsetLeft.X + offsetRight.X) / 2.0;
            offset.Y = (offsetLeft.Y + offsetRight.Y) / 2.0;

            for (int index = 0; index < 2; index++)
            {
                irisHistory.Add(offset);
                if (irisHistory.Count == irisMemory)
                {
                    Vector avgOffset = new Vector();

                    for (int i = 0; i < irisMemory; i++)
                    {
                        avgOffset.X += irisHistory[i].X;
                        avgOffset.Y += irisHistory[i].Y;
                    }

                    avgOffset.X /= irisMemory;
                    avgOffset.Y /= irisMemory;

                    position.X = irisNeutral[index].X + (maxIrisMovement * avgOffset.X);
                    position.Y = irisNeutral[index].Y + (maxIrisMovement * avgOffset.Y);

                    irisHistory.RemoveAt(0);
                }
                else
                {
                    position.X = irisNeutral[index].X + (maxIrisMovement * offset.X);
                    position.Y = irisNeutral[index].Y + (maxIrisMovement * offset.Y);
                }

                Canvas.SetLeft(iris[index], position.X);
                Canvas.SetTop(iris[index], position.Y);
            }
        }

        public void Frown(double offset)
        {
            for (int index = 0; index < 2; index++)
            {
                browHistory.Add(offset);
                double position;
                if (browHistory.Count == browMemory)
                {
                    double avgOffset = 0;
                    for (int i = 0; i < browMemory; i++)
                    {
                        avgOffset += browHistory[i];
                    }

                    avgOffset /= browMemory;
                    browHistory.RemoveAt(0);

                    position = browNeutral + maxBrowMovement * -avgOffset;
                }
                else
                {
                    position = browNeutral + maxBrowMovement * -offset;
                }
                
                Canvas.SetTop(brow[index], position);               
            }
        }

        public void Laugh(double leftOffSet, double centerOffSet, double rightOffset)
        {
            double left, center, right;
            
            Vector3 offsets = new Vector3(leftOffSet, centerOffSet, rightOffset);
            mouthHistory.Add(offsets);
            if (mouthHistory.Count == mouthMemory)
            {
                Vector3 avgOffsets = new Vector3();
                for (int i = 0; i < mouthMemory; i++)
                {
                    avgOffsets.X += mouthHistory[i].X;
                    avgOffsets.Y += mouthHistory[i].Y;
                    avgOffsets.Z += mouthHistory[i].Z;
                }

                avgOffsets.X /= mouthMemory;
                avgOffsets.Y /= mouthMemory;
                avgOffsets.Z /= mouthMemory;

                left = mouthNeutral.Top + maxMouthMovement * avgOffsets.X;
                right = mouthNeutral.Top + maxMouthMovement * avgOffsets.Z;

                center = mouthNeutral.Height + maxMouthMovement * avgOffsets.Y;
                

                mouthHistory.RemoveAt(0);
            }
            else
            {
                left = mouthNeutral.Top + maxMouthMovement * leftOffSet;
                right = mouthNeutral.Top + maxMouthMovement * rightOffset;

                center = mouthNeutral.Height + maxMouthMovement * centerOffSet;
                
            }

            Canvas.SetTop(mouth2, (left + right) / 2.0);
            mouth2.Height = center;
        }

        private struct Vector3
        {
            public double X;
            public double Y;
            public double Z;           

            public Vector3(double x, double y, double z)
            {
                this.X = x;
                this.Y = y;
                this.Z = z;
            }
        }
    }
}
