﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using Luxand;
using System.IO;
using System.Drawing.Imaging;
using System.Windows.Threading;

using WFRectangle = System.Drawing.Rectangle;
using WFImage = System.Drawing.Image;
using WFGraphics = System.Drawing.Graphics;
using TPoint = Luxand.FSDK.TPoint;
using System.Diagnostics;
using System.Configuration;

namespace MimboWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SecondaryWindow secondWindow;
        RobotFace robot;
        string cameraName;
        bool running = false;
        int cameraWidth;
        int cameraHeight;
        DateTime lastUpdate;
        // WinAPI procedure to release HBITMAP handles returned by FSDKCam.GrabFrame
        [DllImport("gdi32.dll")]
        static extern bool DeleteObject(IntPtr hObject);

        public MainWindow()
        {
            InitializeComponent();
            ActivateLuxand();
            SetupCamera();
            lastUpdate = DateTime.Now;
            int smoothing = Int32.Parse(ConfigurationManager.AppSettings["Smoothing"]);
            robot = new RobotFace(leftIris, rightIris, leftBrow, rightBrow, mouth2, smoothing);

            WFRectangle workingArea = System.Windows.Forms.Screen.AllScreens[0].WorkingArea;
            this.Left = workingArea.Left;
            this.Top = workingArea.Top;
            this.Width = workingArea.Width;
            this.Height = workingArea.Height;
            this.Topmost = true;

            secondWindow = new SecondaryWindow();
            secondWindow.WindowStartupLocation = System.Windows.WindowStartupLocation.Manual;

            if (System.Windows.Forms.Screen.AllScreens.Length > 1)
            {

                workingArea = System.Windows.Forms.Screen.AllScreens[1].WorkingArea;
                secondWindow.Left = workingArea.Left;
                secondWindow.Top = workingArea.Top;
                secondWindow.Width = workingArea.Width;
                secondWindow.Height = workingArea.Height;
                secondWindow.Topmost = true;

                secondWindow.Show();
            }
            else
            {
                MessageBox.Show("No secondary monitor detected, only showing robot face", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // Wait for the first render event before drawing
        private void Window_ContentRendered(object sender, EventArgs e)
        {
            if (running == false)
            {                
                running = true;
                Start();
            }
        }

        private void ActivateLuxand()
        {
            //Test license: udvIYrJPSOjjBTQ0fV/EZKXv97l4w1QcKqgc8+azso6zCH+0KxDo1tRK7DL7Zc6yeUCOnJ3xy+mowQL5NzwTMUt7jv4/ttXpe4y+CNMc2eHvrXXk811wrOpJgEz3XtD1jW3iK9ezWeKt0n5YSj+1POJWiSWswcSYyt1C2VcqNuQ=
            string licenseKey = ConfigurationManager.AppSettings["LuxandKey"].ToString();
            if (FSDK.FSDKE_OK != FSDK.ActivateLibrary(licenseKey))
            {
                MessageBox.Show("Luxand License Key Error, please correct the license key in app.config.", "Error activating FaceSDK", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown();
            }

            FSDK.InitializeLibrary();                        
        }

        private void SetupCamera()
        {            
            string[] cameraList;
            int count;
            FSDKCam.InitializeCapturing();
            FSDKCam.GetCameraList(out cameraList, out count);

            if (count == 0)
            {
                MessageBox.Show("Please attach a camera", "Error activating FaceSDK", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown();
            }

            FSDKCam.VideoFormatInfo[] formatList;
            FSDKCam.GetVideoFormatList(ref cameraList[0], out formatList, out count);
            cameraWidth = formatList[0].Width;
            cameraHeight = formatList[0].Height;

            this.Width = cameraWidth * 2;
            this.Height = cameraHeight + 30;

            cameraName = cameraList[0];
        }

        private void AnimateRobot(FSDK.TPoint[] facialFeatures)
        {
            if (facialFeatures != null) // face detected
            {
                AnimateBrows(facialFeatures);
                AnimateEyes(facialFeatures);
                AnimateMouth(facialFeatures);
            }
            else // return to neutral state
            {
                robot.Frown(0.0);
                robot.Look(new Vector(0, 0), new Vector(0, 0));
                robot.Laugh(0, 0, 0);
            }
        }

        private void AnimateMouth(FSDK.TPoint[] facialFeatures)
        {

            double offsetLeft = GetOffset(facialFeatures[(int)FSDK.FacialFeatures.FSDKP_MOUTH_RIGHT_CORNER].y,
                                      facialFeatures[(int)FSDK.FacialFeatures.FSDKP_NASOLABIAL_FOLD_LEFT_UPPER].y,
                                      facialFeatures[(int)FSDK.FacialFeatures.FSDKP_FACE_CONTOUR1].y);

            //double offsetCenter = GetOffset(facialFeatures[(int)FSDK.FacialFeatures.FSDKP_MOUTH_BOTTOM_INNER].y,
            //                          facialFeatures[(int)FSDK.FacialFeatures.FSDKP_NOSE_BOTTOM].y,
            //                          facialFeatures[(int)FSDK.FacialFeatures.FSDKP_CHIN_BOTTOM].y);

            double offsetCenter = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_MOUTH_BOTTOM_INNER].y - facialFeatures[(int)FSDK.FacialFeatures.FSDKP_MOUTH_TOP_INNER].y;
            offsetCenter /= (facialFeatures[(int)FSDK.FacialFeatures.FSDKP_MOUTH_TOP].y - facialFeatures[(int)FSDK.FacialFeatures.FSDKP_NOSE_BOTTOM].y);

            offsetCenter = Math.Min(Math.Max(offsetCenter, 0), 1);
            //Add smile bias
            //offsetCenter *= 8.0;

            double offsetRight = GetOffset(facialFeatures[(int)FSDK.FacialFeatures.FSDKP_MOUTH_LEFT_CORNER].y,
                                      facialFeatures[(int)FSDK.FacialFeatures.FSDKP_NASOLABIAL_FOLD_RIGHT_UPPER].y,
                                      facialFeatures[(int)FSDK.FacialFeatures.FSDKP_FACE_CONTOUR13].y);            

            robot.Laugh(Clamp(offsetLeft), offsetCenter, Clamp(offsetRight));
        }

        private static double GetOffset(double center, double min, double max)
        {
            double c = (max + min) / 2.0;            
            double range = max - min;
            return (center - min) / range - 0.5;            
        }

        private void AnimateBrows(FSDK.TPoint[] facialFeatures)
        {
            double positionLeft = ProcessBrow(facialFeatures, facialFeatures[(int)FSDK.FacialFeatures.FSDKP_LEFT_EYEBROW_MIDDLE].y, facialFeatures[(int)FSDK.FacialFeatures.FSDKP_LEFT_EYE_UPPER_LINE2].y);
            double positionRight = ProcessBrow(facialFeatures, facialFeatures[(int)FSDK.FacialFeatures.FSDKP_RIGHT_EYEBROW_MIDDLE].y, facialFeatures[(int)FSDK.FacialFeatures.FSDKP_RIGHT_EYE_UPPER_LINE2].y);
            robot.Frown(Clamp((positionLeft + positionRight) / 2.0));
        }

        private static double ProcessBrow(FSDK.TPoint[] facialFeatures, double browBottom, double eyeTop)
        {
            double neutralDistance = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_MOUTH_TOP].y - facialFeatures[(int)FSDK.FacialFeatures.FSDKP_NOSE_BOTTOM].y;
            double position = (eyeTop - browBottom) / neutralDistance - 0.5;
            return position;
        }

        private void AnimateEyes(FSDK.TPoint[] facialFeatures)
        {
            double positionLeftX;
            double positionLeftY;
            double positionRightX;
            double positionRightY;

            //Left eye
            TPoint leftCorner = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_LEFT_EYE_OUTER_CORNER];
            TPoint iris = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_LEFT_EYE];
            TPoint rightCorner = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_LEFT_EYE_INNER_CORNER];
            TPoint up = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_LEFT_EYE_UPPER_LINE2];
            TPoint down = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_LEFT_EYE_LOWER_LINE2];            

            ProcessIris(leftCorner, iris, rightCorner, up, down, out positionLeftX, out positionLeftY);            

            //Right eye
            leftCorner = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_RIGHT_EYE_INNER_CORNER];
            iris = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_RIGHT_EYE];
            rightCorner = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_RIGHT_EYE_OUTER_CORNER];
            up = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_RIGHT_EYE_UPPER_LINE2];
            down = facialFeatures[(int)FSDK.FacialFeatures.FSDKP_RIGHT_EYE_LOWER_LINE2];


            ProcessIris(leftCorner, iris, rightCorner, up, down, out positionRightX, out positionRightY);

            double exag = 5;
            positionLeftX = Clamp(positionLeftX * exag);
            positionLeftY = Clamp(positionLeftY * exag);
            positionRightX = Clamp(positionRightX * exag);
            positionRightY = Clamp(positionRightY * exag);

            robot.Look(new Vector(positionLeftX, positionLeftY), new Vector(positionRightX, positionRightY));            

            //Console.Out.WriteLine("leftIris: " + Math.Round(positionX, 2) + ", " + Math.Round(positionY, 2));
        }   

        private static void ProcessIris(TPoint leftCorner, TPoint iris, TPoint rightCorner, TPoint up, TPoint down, out double positionX, out double positionY)
        {
            double centerX = (leftCorner.x + rightCorner.x) / 2.0;
            double rangeX = rightCorner.x - leftCorner.x;
            positionX = ((iris.x - leftCorner.x) / rangeX) - 0.5;

            double centerY = (down.y + up.y) / 2.0;
            double rangeY = down.y - up.y;
            positionY = ((iris.y - up.y) / rangeY) - 0.5;
        }

        private double Clamp(double value)
        {
            if (value < -1.0) { value = -1.0; }
            else if (value > 1.0) { value = 1.0; }

            return value;
        }

        // TODO: All the code in this region should be moved outside of this class
        // and should be run in a separate thread! The face data and image should be passed using
        // a background worker.
        #region ToMove
        List<FSDK.TPoint[]> facialFeaturesArray = new List<FSDK.TPoint[]>();
        int smoothingLength = 10;

        private void ResetSmoothing()
        {
            facialFeaturesArray.Clear();
        }

        /// <summary>
        /// TODO this smoothing doesnt seem to do much at all!
        /// </summary>
        /// <param name="facialFeaturesArray"></param>
        /// <param name="facialFeatures"></param>
        void SmoothFeatureList(List<FSDK.TPoint[]> facialFeaturesArray, ref FSDK.TPoint[] facialFeatures)
        {
            // You may change these coefficients if you need to increase or decrease the smoothing
            double SpatialSmoothingCoeff = 0.5 * Math.Sqrt((facialFeatures[0].x - facialFeatures[1].x) * (facialFeatures[0].x - facialFeatures[1].x)
                                + (facialFeatures[0].y - facialFeatures[1].y) * (facialFeatures[0].y - facialFeatures[1].y));
            double TemporalSmoothingCoeff = 250;

            FSDK.TPoint OldCenter = new FSDK.TPoint();
            FSDK.TPoint NewCenter = new FSDK.TPoint();
            OldCenter.x = 0;
            OldCenter.y = 0;
            NewCenter.x = 0;
            NewCenter.y = 0;
            for (int i = 0; i < FSDK.FSDK_FACIAL_FEATURE_COUNT; i++)
            {
                OldCenter.x += facialFeatures[i].x;
                OldCenter.y += facialFeatures[i].y;
                double x = 0;
                double y = 0;
                double xSumOfWeights = 0;
                double ySumOfWeights = 0;
                for (int j = 0; j < smoothingLength; j++)
                {
                    double xWeight = Math.Exp(-(facialFeaturesArray[j][i].x - facialFeatures[i].x) * (facialFeaturesArray[j][i].x - facialFeatures[i].x)
                                                / SpatialSmoothingCoeff - (j - smoothingLength + 1) * (j - smoothingLength + 1) / TemporalSmoothingCoeff);
                    double yWeight = Math.Exp(-(facialFeaturesArray[j][i].y - facialFeatures[i].y) * (facialFeaturesArray[j][i].y - facialFeatures[i].y)
                                                / SpatialSmoothingCoeff - (j - smoothingLength + 1) * (j - smoothingLength + 1) / TemporalSmoothingCoeff);
                    xSumOfWeights += xWeight;
                    ySumOfWeights += yWeight;
                    x += xWeight * facialFeaturesArray[j][i].x;
                    y += yWeight * facialFeaturesArray[j][i].y;
                }
                facialFeatures[i].x = (int)(x / xSumOfWeights);
                facialFeatures[i].y = (int)(y / ySumOfWeights);
                NewCenter.x += facialFeatures[i].x;
                NewCenter.y += facialFeatures[i].y;
            }
            OldCenter.x /= FSDK.FSDK_FACIAL_FEATURE_COUNT;
            OldCenter.y /= FSDK.FSDK_FACIAL_FEATURE_COUNT;
            NewCenter.x /= FSDK.FSDK_FACIAL_FEATURE_COUNT;
            NewCenter.y /= FSDK.FSDK_FACIAL_FEATURE_COUNT;
            for (int i = 0; i < FSDK.FSDK_FACIAL_FEATURE_COUNT; i++)
            {
                facialFeatures[i].x += OldCenter.x - NewCenter.x;
                facialFeatures[i].y += OldCenter.y - NewCenter.y;
            }
        }

        private void SmoothFacialFeatures(ref FSDK.TPoint[] facialFeatures)
        {
            facialFeaturesArray.Add(facialFeatures);
            if (facialFeaturesArray.Count == smoothingLength)
            {
                SmoothFeatureList(facialFeaturesArray, ref facialFeatures);
                facialFeaturesArray.RemoveAt(0);
            }
        }

        private void Start()
        {                        
            int cameraHandle = 0;

            int r = FSDKCam.OpenVideoCamera(ref cameraName, ref cameraHandle);
            if (r != FSDK.FSDKE_OK)
            {
                MessageBox.Show("Error opening the first camera", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown();
            }

            // set realtime face detection parameters
            FSDK.SetFaceDetectionParameters(false, false, 100);
            FSDK.SetFaceDetectionThreshold(3);

            while (running)
            {
                Int32 imageHandle = 0;
                if (FSDK.FSDKE_OK != FSDKCam.GrabFrame(cameraHandle, ref imageHandle)) // grab the current frame from the camera
                {
                    DoEvents();
                    continue;
                }
                FSDK.CImage image = new FSDK.CImage(imageHandle);

                WFImage frameImage = image.ToCLRImage();
                WFGraphics gr = WFGraphics.FromImage(frameImage);

                FSDK.TFacePosition facePosition = image.DetectFace();

                // if a face is detected, we detect facial features
                if (facePosition.w != 0)
                {
                    FSDK.TPoint[] facialFeatures = image.DetectFacialFeaturesInRegion(ref facePosition);

                    SmoothFacialFeatures(ref facialFeatures);

                    
                    foreach (FSDK.TPoint point in facialFeatures)
                        gr.FillEllipse(System.Drawing.Brushes.DarkBlue, point.x, point.y, 3, 3);
                    gr.DrawRectangle(System.Drawing.Pens.LightGreen, facePosition.xc - 2 * facePosition.w / 3, facePosition.yc - facePosition.w / 2,
                        4 * facePosition.w / 3, 4 * facePosition.w / 3);

                    DrawFaceOverlay(gr, facialFeatures);


                    AnimateRobot(facialFeatures);
                }
                else // if a face is disappeared, we reset smoothing parameters
                {
                    ResetSmoothing();
                    AnimateRobot(null);
                }
                
                // display current frame                
                secondWindow.GetDrawTarget().Source = ConvertToImage(frameImage);                

                double miliseconds = (DateTime.Now - lastUpdate).TotalMilliseconds;
                lastUpdate = DateTime.Now;
                
                // make UI controls accessible
                DoEvents();
            }

            FSDKCam.CloseVideoCamera(cameraHandle);
            FSDKCam.FinalizeCapturing();
        }

        private void DrawFaceOverlay(WFGraphics gr, FSDK.TPoint[] facialFeatures)
        {
            //Under mouth
            TPoint[] trianglePoints = new TPoint[]
                    {
                        facialFeatures[52],
                        facialFeatures[5], 
                        facialFeatures[3], 
                        facialFeatures[7], 
                        facialFeatures[58], 
                        facialFeatures[9], 
                        facialFeatures[55], 
                        facialFeatures[11], 
                        facialFeatures[59], 
                        facialFeatures[10], 
                        facialFeatures[4], 
                        facialFeatures[8],                      
                        facialFeatures[53], 
                        facialFeatures[6] 
                    };
            DrawTriangleStrip(trianglePoints, gr);

            //Over mouth
            trianglePoints = new TPoint[]
                    {
                        facialFeatures[52],
                        facialFeatures[3], 
                        facialFeatures[50], 
                        facialFeatures[56], 
                        facialFeatures[45], 
                        facialFeatures[54], 
                        facialFeatures[49], 
                        facialFeatures[57], 
                        facialFeatures[46], 
                        facialFeatures[4], 
                        facialFeatures[51], 
                        facialFeatures[53]                        
                    };
            DrawTriangleStrip(trianglePoints, gr);

            //Left eye
            trianglePoints = new TPoint[]
                    {
                        facialFeatures[12],
                        facialFeatures[23], 
                        facialFeatures[18], 
                        facialFeatures[35], 
                        facialFeatures[16], 
                        facialFeatures[28], 
                        facialFeatures[19], 
                        facialFeatures[36], 
                        facialFeatures[13],                         
                        facialFeatures[24]
                    };
            DrawTriangleStrip(trianglePoints, gr);

            //Right eye
            trianglePoints = new TPoint[]
                    {
                        facialFeatures[25],
                        facialFeatures[14], 
                        facialFeatures[39], 
                        facialFeatures[20], 
                        facialFeatures[32], 
                        facialFeatures[17], 
                        facialFeatures[40], 
                        facialFeatures[21], 
                        facialFeatures[26],                         
                        facialFeatures[15]
                    };
            DrawTriangleStrip(trianglePoints, gr);

            //Upper nose
            trianglePoints = new TPoint[]
                    {
                        facialFeatures[24],
                        facialFeatures[43], 
                        facialFeatures[22], 
                        facialFeatures[44], 
                        facialFeatures[25]                        
                    };
            DrawTriangleStrip(trianglePoints, gr);

            //Lower nose
            trianglePoints = new TPoint[]
                    {
                        facialFeatures[45],
                        facialFeatures[43], 
                        facialFeatures[47], 
                        facialFeatures[2], 
                        facialFeatures[48],
                        facialFeatures[44], 
                        facialFeatures[46]                         
                    };
            DrawTriangleStrip(trianglePoints, gr);


            //Nose tip
            trianglePoints = new TPoint[]
                    {
                        facialFeatures[47],
                        facialFeatures[48], 
                        facialFeatures[49]                        
                    };
            DrawTriangleStrip(trianglePoints, gr);
        }

        private void DrawTriangleStrip(TPoint[] p, WFGraphics gr)
        {
            List<System.Drawing.Point> points = new List<System.Drawing.Point>();
            for (int i = 2; i < p.Length; i++)
            {
                points.Add(new System.Drawing.Point(p[i].x, p[i].y));
                points.Add(new System.Drawing.Point(p[i-2].x, p[i-2].y));
                points.Add(new System.Drawing.Point(p[i-1].x, p[i-1].y));
            }

            points.Add(new System.Drawing.Point(p[p.Length - 1].x, p[p.Length - 1].y));

            System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Brushes.Blue);
            gr.DrawLines(pen, points.ToArray());
        }

        private BitmapImage ConvertToImage(WFImage wFImage)
        {            
            BitmapImage bi = new BitmapImage();
            bi.BeginInit();
            MemoryStream ms = new MemoryStream();
            wFImage.Save(ms, ImageFormat.Bmp);
            ms.Seek(0, SeekOrigin.Begin);
            bi.StreamSource = ms;
            bi.EndInit();
            
            return bi;
        }

        //HACK
        public static void DoEvents()
        {
            if(Application.Current != null)
                Application.Current.Dispatcher.Invoke(DispatcherPriority.Background,
                                                  new Action(delegate { }));
        }
        #endregion

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            running = false;
            Application.Current.Shutdown();
        }    
    }
}
