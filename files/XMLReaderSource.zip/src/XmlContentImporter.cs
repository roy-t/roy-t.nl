using System;
using System.Xml;
using Microsoft.Xna.Framework.Content.Pipeline;

namespace ContentPipelineExtensions.Xml
{
    [ContentImporter(".xml", DisplayName = "XML Content Importer - LogisticsGame", DefaultProcessor = "None")]  
    public class XmlContentImporter : ContentImporter<XmlDocument>
    {
        public override XmlDocument Import(string filename, ContentImporterContext context)
        {
            XmlDocument document = new XmlDocument();
            try
            {
                document.Load(filename);
            }
            catch (Exception e)
            {
                //Write error logger here or update the exception with more information
                throw e;
            }
            return document;
        }
    }
}
