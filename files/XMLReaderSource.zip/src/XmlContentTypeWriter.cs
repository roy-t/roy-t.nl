using System.Xml;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Serialization.Compiler;

namespace ContentPipelineExtensions.Xml
{
    [ContentTypeWriter()]
    public class XmlContentTypeWriter : ContentTypeWriter<XmlDocument>
    {
        protected override void Write(ContentWriter output, XmlDocument value)
        {
            value.Save(output.BaseStream);
        }

        public override string GetRuntimeType(TargetPlatform targetPlatform)
        {
            return typeof(XmlDocument).AssemblyQualifiedName;
        }

        public override string GetRuntimeReader(TargetPlatform targetPlatform)
        {
			// This is very important, double check this line in your code!
			// Because of circular references this has to be a string (flackey I know :( )
            return "ContentTypes.ContentTypeReaders.XmlContentTypeReader, ContentTypes, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null";
        }
    }
}
