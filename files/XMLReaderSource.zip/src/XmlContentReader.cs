using System.Xml;
using Microsoft.Xna.Framework.Content;


namespace ContentTypes.ContentTypeReaders
{    
    public class XmlContentTypeReader : ContentTypeReader<XmlDocument>
    {
        protected override XmlDocument Read(ContentReader input, XmlDocument existingInstance)
        {
            if (existingInstance == null)
            {
                existingInstance = new XmlDocument();
            }

            existingInstance.Load(input.BaseStream);
            return existingInstance;
        }
    }
}
