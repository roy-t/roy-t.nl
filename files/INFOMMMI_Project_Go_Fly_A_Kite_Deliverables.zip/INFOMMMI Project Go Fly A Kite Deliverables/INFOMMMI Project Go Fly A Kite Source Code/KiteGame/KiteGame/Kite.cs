﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace KiteGame
{
    public class Kite
    {
        private const float gravity = 130;
        private const float wind_force = 180;

        private Texture2D texture;
        private Vector2 origin;

        public float Scale { get; set; }
        public Vector2 Position { get; set; }

        public Kite(Texture2D texture, float scale)
        {
            this.Scale = scale;
            this.texture = texture;
            this.origin = new Vector2(texture.Width / 2.0f, texture.Height / 2.0f);
        }        

        public void Update(Wind wind, float elapsedSeconds)
        {            
            Vector2 arrow_to_kite = Vector2.Normalize(new Vector2(Position.X - 640, 768 - Position.Y));
            Vector2 wind_arrow = Vector2.Normalize(Vector2.Transform(Vector2.UnitY, Matrix.CreateRotationZ(-wind.Angle)));

            float dot = Vector2.Dot(arrow_to_kite, wind_arrow);
            dot = (float)Math.Pow(dot, 15);

            Control(elapsedSeconds);

            Position -= Vector2.UnitY * -gravity * elapsedSeconds;
            Position += Vector2.UnitY * -wind_force * elapsedSeconds * dot;

            if (Position.Y <= 75) { Position = new Vector2(Position.X, 75); }
            else if (Position.Y >= 500) { Position = new Vector2(Position.X, 500); }
        }


        private float speed = 200;
        private void Control(float elapsedSeconds)
        {
            KeyboardState state = Keyboard.GetState();
            if (state.IsKeyDown(Keys.Left))
            {
                Position -= Vector2.UnitX * speed * elapsedSeconds;
            }
            else if (state.IsKeyDown(Keys.Right))
            {
                Position += Vector2.UnitX * speed * elapsedSeconds;
            }
        }



        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, Position, null, Color.White, 0.0f, origin, Scale, SpriteEffects.None, 0.0f);
        }
    }
}
