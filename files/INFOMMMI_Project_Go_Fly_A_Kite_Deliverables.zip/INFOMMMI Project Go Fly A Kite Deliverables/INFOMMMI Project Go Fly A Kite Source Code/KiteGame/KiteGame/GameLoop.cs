using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using amBXLib;

namespace KiteGame
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class GameLoop : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;
        AMBXController AMBX;

        Kite kite;
        Wind wind;
        KeyboardState prevKeyboardState;

        bool draw_arrow = true;
        bool simulate_wind = true;

        float score;
        DateTime start_time;

        public GameLoop()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 1280;
            graphics.PreferredBackBufferHeight = 768;

            Content.RootDirectory = "Content";            
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            AMBX = new AMBXController();

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            font = Content.Load<SpriteFont>("SpriteFont");

            kite = new Kite(Content.Load<Texture2D>(@"Leaf"), 1.0f);                        
            wind = new Wind(Content.Load<Texture2D>(@"Arrow"));            
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            AMBX.Dispose();
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            float elapsedSeconds = (float)gameTime.ElapsedGameTime.TotalSeconds;
            KeyboardState curKeyboardState = Keyboard.GetState();

            wind.Update(elapsedSeconds);
            kite.Update(wind, elapsedSeconds);
            
            if (curKeyboardState.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }

            if (simulate_wind)
            {                
                Vector2 intensities = wind.CalculateWindIntensity(elapsedSeconds);
                AMBX.SetPower(intensities.X, intensities.Y);
            }
            else
            {
                AMBX.SetPower(0.0f, 0.0f);
            }            


            // Controls
            if (prevKeyboardState.IsKeyUp(Keys.W) && curKeyboardState.IsKeyDown(Keys.W))
            {
                simulate_wind = !simulate_wind;
            }

            if (prevKeyboardState.IsKeyUp(Keys.A) && curKeyboardState.IsKeyDown(Keys.A))
            {
                draw_arrow = !draw_arrow;
            }

            if (prevKeyboardState.IsKeyUp(Keys.R) && curKeyboardState.IsKeyDown(Keys.R))
            {
                Reset();
            }

            prevKeyboardState = curKeyboardState;            

            // Update score            
            score += (graphics.PreferredBackBufferHeight - kite.Position.Y) / 100.0f;
            
            base.Update(gameTime);
        }

        private void Reset()
        {
            score = 0.0f;            
            start_time = DateTime.Now;

            kite.Position = new Vector2(640, 100);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            double average_score = score / (DateTime.Now - start_time).TotalSeconds;

            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.Default, RasterizerState.CullNone);

            kite.Draw(spriteBatch);

            if (draw_arrow)
            {
                wind.Draw(spriteBatch);
            }

            spriteBatch.DrawString(font, "Average Height " + Math.Round(average_score, 2), new Vector2(15, graphics.PreferredBackBufferHeight - 50), Color.White);
            spriteBatch.DrawString(font, "Time " + (DateTime.Now - start_time).ToString(@"mm\:ss"), new Vector2(15, graphics.PreferredBackBufferHeight - 25), Color.White);
            

            spriteBatch.End();
            

            base.Draw(gameTime);
        }
    }
}
