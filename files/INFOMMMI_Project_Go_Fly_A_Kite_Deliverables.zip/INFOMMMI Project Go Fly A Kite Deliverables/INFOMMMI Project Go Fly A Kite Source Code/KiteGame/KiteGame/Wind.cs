﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace KiteGame
{
    public class Wind
    {               
        public float Angle { get; private set; }
        public float Strength { get; private set; }

        private WindState windState;
        private Random random;
        private float waitTime = 0.0f;        
        private float targetWaitTime = 0.0f;
        private float targetAngle = 0.0f;
        private float convergeSpeed = 1.0f;
        private float convergeTime = 0.0f;

        public Wind(Texture2D texture)
        {
            this.texture = texture;
            Angle = 0.0f;
            Strength = 1.0f;

            random = new Random();
        }

        /// <summary>
        /// .x = left, .y = right
        /// </summary>
        /// <returns></returns>
        public Vector2 CalculateWindIntensity(float elapsedSeconds)
        {
            // + PI/2 -> x = Strength, y = 0
            // - PI/2 -> x = 0, y = Srength
            // 0 -> x = 0.5 * Strength, y = 0.5 * Strength

            Vector2 intensities;
            intensities.X = (((Angle - MathHelper.PiOver2) * -1.0f) / MathHelper.Pi) * Strength;
            intensities.Y = ((Angle + MathHelper.PiOver2) / MathHelper.Pi) * Strength;

            Vector2 discreteIntensities;
            discreteIntensities.X = Discretize(intensities.X);
            discreteIntensities.Y = Discretize(intensities.Y);

            Vector2 temp = Vector2.Lerp(intensities, discreteIntensities, 40.0f * elapsedSeconds);


            //Console.Out.WriteLine("X: " + Math.Round(temp.X, 2) + " Y: " + Math.Round(temp.Y, 2) + " Angle: " + Math.Round(Angle, 2));

            return temp;
        }

        public float Discretize(float value)
        {            
            if (value > 0.66f)                
                return 1.0f;
            else if (value < 0.33)
                return 0.1f;
            else
                return 0.5f;
        }

        public void Reset()
        {

        }

        public void Update(float elapsedSeconds)
        {
            switch (windState)
            {
                case WindState.Converging:

                    float diff = Angle - targetAngle;
                    convergeTime += elapsedSeconds;
                    Angle = Angle - diff * convergeSpeed * elapsedSeconds;

                    if (Math.Abs(diff) < (convergeSpeed * elapsedSeconds) ||
                        convergeTime > 5.0f)
                    {                        
                        windState = WindState.Waiting;
                    }

                    break;

                case WindState.Waiting:

                    waitTime += elapsedSeconds;
                    if (waitTime > targetWaitTime)
                    {
                        targetAngle = ((float)random.NextDouble() - 0.5f) * MathHelper.PiOver2;                        
                        targetWaitTime = (float)random.NextDouble() * 5.0f;
                        convergeSpeed = 2.0f * ((float)random.NextDouble() + 0.2f);

                        waitTime = 0.0f;
                        convergeTime = 0.0f;
                        windState = WindState.Converging;
                    }

                    break;
            }
        }


        private Texture2D texture;
        public void Draw(SpriteBatch spriteBatch)
        {
            Vector2 origin = new Vector2(texture.Width / 2.0f, texture.Height / 2.0f);
            Vector2 position = new Vector2(640, 680);
            spriteBatch.Draw(texture, position, null, Color.White, Angle, origin, 0.5f, SpriteEffects.None, 0.0f);
        }

        private enum WindState
        {
            Converging,
            Waiting
        }
    }
}
