﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using amBXLib;

namespace KiteGame
{
    public class AMBXController : IDisposable
    {
        private bool valid = false;
        private amBX AMBX;
        private amBXFan leftFan, rightFan;

        public AMBXController()
        {

            try
            {
                AMBX = new amBX(1, 0, "KiteGame", "v1.0");
                leftFan = AMBX.CreateFan(CompassDirection.NorthWest, RelativeHeight.AnyHeight);
                leftFan.Enabled = true;
                leftFan.Intensity = 0;

                rightFan = AMBX.CreateFan(CompassDirection.NorthEast, RelativeHeight.AnyHeight);
                rightFan.Enabled = true;
                rightFan.Intensity = 0;

                valid = true;
            }
            catch (Exception ex)
            {
                valid = false;
            }
        }

        public void SetPower(float left, float right)
        {
            if (valid)
            {
                leftFan.Intensity = left;
                rightFan.Intensity = right;
            }
        }        

        public void Dispose()
        {
            if (valid)
            {
                leftFan.Intensity = 0.0f;
                leftFan.Enabled = false;

                rightFan.Intensity = 0.0f;
                rightFan.Enabled = false;

                AMBX.Dispose();
            }
        }
    }
}
