Our program will run on Windows XP, Vista, 7, and 8 if the following prequisites are installed.

Before you can run our prototype you will have to install:

- The .NET 4.0 Framework, http://www.microsoft.com/en-us/download/details.aspx?id=17851
- The XNA 4.0 Framework, http://www.microsoft.com/en-us/download/details.aspx?id=20914

After this the program will launch, but to enable amBX support (if you have a Philips amBX system)
so that you can experience the wind  modality you will need to perform the steps described here
http://www.ambx.com/wiki/Installation


