﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace DemoProject
{
    public class GameObject
    {        
        public Point Position { get; set; }
        public Point Size { get; set; }

        public int X { get { return Position.X; } set { Position = new Point(value, Position.Y); } }
        public int Y { get { return Position.Y; } set { Position = new Point(Position.X, value); } }

        public int Width { get { return Size.X; } set { Size = new Point(value, Size.Y); } }
        public int Height { get { return Size.Y; } set { Size = new Point(Size.X, value); } }        

        private Texture2D colorTexture;
        public Color Color { get; set; }

        public GameObject(int x, int y, int width, int height, Color color)
            : this(new Point(x, y), new Point(width, height), color) { }

        public GameObject(Point position, Point size, Color color)
        {            
            this.Position = position;
            this.Size = size;
            this.Color = color;

            colorTexture = new Texture2D(GameServices.GetService<GraphicsDevice>(), 1, 1);
            colorTexture.SetData<Color>(new Color[] { Color.White });
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(colorTexture, new Rectangle(X, Y, Width, Height), Color);
        }
    }
}
