for(i=0; i < 5; i++){ 
 	 player.X += 5; 
}

player.Y += 30;