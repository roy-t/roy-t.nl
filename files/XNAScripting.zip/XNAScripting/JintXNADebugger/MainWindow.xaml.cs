﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Reflection;
using Microsoft.Win32;
using System.IO;

namespace JintXNADebugger
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DemoProject.Game1 game;
        private Storm.TextEditor.TextEditor editor;
        public MainWindow()
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(RunGame));
            InitializeComponent();
            
            editor = new Storm.TextEditor.TextEditor();
            editor.AutomaticLanguageDetection = false;
            editor.CurrentLanguage = Storm.TextEditor.Languages.XmlLanguage.JavaScript;
            editor.Document.BreakpointAdded += new Storm.TextEditor.Editor.RowEventHandler(Document_BreakpointAdded);
            editor.Document.BreakpointRemoved += new Storm.TextEditor.Editor.RowEventHandler(Document_BreakpointRemoved);
            editor.HighlightedLineColor = System.Drawing.Color.Yellow;
            editorHost.Child = editor;                     
        }

        private void Document_BreakpointRemoved(object sender, Storm.TextEditor.Editor.RowEventArgs e)
        {
            int line;
            int @char;
            GetBreakpointPosition(e, out line, out @char);
            game.ScriptEngine.RemoveBreakpoint(line, @char);
        }

        private void Document_BreakpointAdded(object sender, Storm.TextEditor.Editor.RowEventArgs e)
        {
            int line;
            int @char;
            GetBreakpointPosition(e, out line, out @char);
            game.ScriptEngine.AddBreakpoint(line, @char);
        }

        private void GetBreakpointPosition(Storm.TextEditor.Editor.RowEventArgs e, out int line, out int @char)
        {
            line = e.Row.Index + 1;
            @char = 0;
            char[] charachters = e.Row.Text.ToCharArray();
            for (int i = 0; i < charachters.Length; i++)
            {
                if (!Char.IsWhiteSpace(charachters[i]))
                {
                    @char = i;
                    break;
                }
            }
        }

        private void RunGame(Object stateInfo)
        {
            using (game = new DemoProject.Game1())
            {
                game.ScriptEngine.OnStep += new JintXNA.ScriptEngine.ScriptEngineEvent(ScriptEngine_OnStep);
                game.ScriptEngine.OnBreak += new JintXNA.ScriptEngine.ScriptEngineEvent(ScriptEngine_OnBreak);
                game.ScriptEngine.OnCompleted += new JintXNA.ScriptEngine.ScriptEngineEvent(ScriptEngine_OnCompleted);
                game.Run();
            }            
        }

        private void ScriptEngine_OnCompleted(JintXNA.DebugInformation e)
        {
            if (this.Dispatcher.CheckAccess())
            {
                statusBar.Background = Brushes.LightGray;
                listBoxCallstack.ItemsSource = null;
                listViewLocals.ItemsSource = null;
                game.ScriptEngine.PauseOnStep = false;
                editor.HighlightActiveLine = false;
            }
            else
            {
                this.Dispatcher.Invoke(new Action<JintXNA.DebugInformation>(ScriptEngine_OnCompleted), e);
            }
        }

        private void ScriptEngine_OnBreak(JintXNA.DebugInformation e)
        {
            if (this.Dispatcher.CheckAccess())
            {
                DistillRuntimeInfo(e);
                statusBar.Background = Brushes.Red;
                if (game.ScriptEngine.LastException != null)
                {
                    Exception current = game.ScriptEngine.LastException;
                    while(current != null)
                    {
                        textBlockOutput.Text += current.Message + Environment.NewLine;
                        current = current.InnerException;
                    }
                    game.ScriptEngine.ClearExceptions();
                    tabItemTrace.IsSelected = true;
                }
            }
            else
            {
                this.Dispatcher.Invoke(new Action<JintXNA.DebugInformation>(ScriptEngine_OnBreak), e);
            }
        }

        private void ScriptEngine_OnStep(JintXNA.DebugInformation e)
        {
            if (this.Dispatcher.CheckAccess())
            {
                textBlockOutput.Text += String.Format("{0}:{1}, {2}", e.Line, e.Char, e.Statement) + Environment.NewLine;
                if (game.ScriptEngine.PauseOnStep)
                {
                    editor.Caret.SetPosition(new Storm.TextEditor.Editor.Text.TextPoint(e.Char, e.Line - 1));
                    DistillRuntimeInfo(e);
                }              
            }
            else
            {
                this.Dispatcher.Invoke(new Action<JintXNA.DebugInformation>(ScriptEngine_OnStep), e);
            }
        }

        private void DistillRuntimeInfo(JintXNA.DebugInformation e)
        {
            listViewLocals.ItemsSource = e.Locals;
            if (e.CallStack.Count == 0)
            {
                Stack<string> emptyStack = new Stack<string>();
                emptyStack.Push("Callstack is empty");

                listBoxCallstack.ItemsSource = emptyStack;
            }
            else
            {
                listBoxCallstack.ItemsSource = e.CallStack;
            }
        }

        #region ToolBarButtons

        private void buttonUndo_Click(object sender, RoutedEventArgs e)
        {
            editor.Undo();
        }

        private void buttonRedo_Click(object sender, RoutedEventArgs e)
        {
            editor.Redo();
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.AddExtension = true;
            dialog.Filter = "Javascript files (*.js)|*.js|All files (*.*)|*.*";
            dialog.DefaultExt = "js";
            bool? result = dialog.ShowDialog();
            if (result.GetValueOrDefault(false))
            {
                using (StreamWriter writer = new StreamWriter(dialog.OpenFile()))
                {
                    writer.Write(editor.Text);
                    writer.Flush();
                    writer.Close();
                }

                this.Title = "XNA Script Editor: " + dialog.FileName;
            }
        }

        private void buttonLoad_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Javascript files (*.js)|*.js|All files (*.*)|*.*";
            dialog.DefaultExt = "js";
            bool? result = dialog.ShowDialog();
            if (result.GetValueOrDefault(false))
            {
                using (StreamReader reader = new StreamReader(dialog.OpenFile()))
                {
                    editor.Text = reader.ReadToEnd();
                    reader.Close();
                }

                this.Title = "XNA Script Editor: " + dialog.FileName;
            }
        }      

        private void buttonStep_Click(object sender, RoutedEventArgs e)
        {
            if (game.ScriptEngine.IsRunning)
            {
                MessageBox.Show("No scripts currently in paused state", "Info", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            }
            else
            {
                editor.HighlightActiveLine = true;                
                game.ScriptEngine.PauseOnStep = true;
                game.ScriptEngine.Resume();
            }
        }

        private void buttonRun_Click(object sender, RoutedEventArgs e)
        {
            statusBar.Background = Brushes.LightGreen;

            if (game.ScriptEngine.IsRunning)
            {
                textBlockOutput.Text = String.Empty;           
                game.ScriptEngine.QueueScript(editor.Text);               
            }
            else
            {
                listViewLocals.ItemsSource = null;
                listBoxCallstack.ItemsSource = null;
                editor.HighlightActiveLine = false;
                game.ScriptEngine.PauseOnStep = false;
                game.ScriptEngine.Resume();
            }
        }

        private void buttonStop_Click(object sender, RoutedEventArgs e)
        {
            if (!game.ScriptEngine.IsRunning)
            {
                game.ScriptEngine.StopScripts();
            }
            else
            {
                MessageBox.Show("Nothing to stop", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        #endregion
    }
}
