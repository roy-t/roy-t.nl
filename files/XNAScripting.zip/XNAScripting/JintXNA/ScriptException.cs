﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JintXNA
{
    public class ScriptException : Exception
    {
        public int Line { get; private set; }
        public int Char { get; private set; }
        public string Statement { get; private set; }

        public ScriptException(int line, int @char, string statement, Exception innerException)
            : base(String.Format("Exception near Line {0} Char {1},  {2}.", line, @char, statement), innerException)
        {
            this.Line = line;
            this.Char = @char;
            this.Statement = Statement;
        }
    }
}
