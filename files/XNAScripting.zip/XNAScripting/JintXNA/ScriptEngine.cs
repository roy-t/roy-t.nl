﻿using System;
using System.Collections.Generic;
using Jint;
using System.Threading;

namespace JintXNA
{
    public class ScriptEngine
    {
        private JintEngine engine;
        private Queue<string> scriptQueue = new Queue<string>();
        private static AutoResetEvent autoEvent = new AutoResetEvent(false);

        public ScriptException LastException { get; private set; }
        public DebugInformation DebugInfo { get; private set; }

        public delegate void ScriptEngineEvent(DebugInformation e);
        public event ScriptEngineEvent OnBreak;
        public event ScriptEngineEvent OnStep;
        public event ScriptEngineEvent OnCompleted;

        public bool IsRunning { get; private set; }
        public bool DebugMode { get; private set; }
        public bool PauseOnStep { get; set; }

        public ScriptEngine(Object game, bool debugMode)
        {            
            engine = new JintEngine();
            engine.SetParameter("game", game);

            DebugMode = debugMode;

            if (debugMode)
            {
                engine.SetDebugMode(true);                
                engine.Step += new EventHandler<Jint.Debugger.DebugInformation>(Engine_Step);
                engine.Break += new EventHandler<Jint.Debugger.DebugInformation>(Engine_Break);
            }

            this.IsRunning = true;
        }

        public void Pause()
        {
            IsRunning = false;
            autoEvent.WaitOne();
        }

        public void Resume()
        {
            autoEvent.Set();
            IsRunning = true;
        }

        private void Engine_Break(object sender, Jint.Debugger.DebugInformation e)
        {
            Engine_Step(sender, e);             
            Break();
        }

        private void Break()
        {
            if (OnBreak != null)
            {
                if(DebugInfo != null)
                    OnBreak(DebugInfo);
                else
                    OnBreak(new DebugInformation(0, 0));
            }

            Pause();
        }

        private void Engine_Step(object sender, Jint.Debugger.DebugInformation e)
        {
            DebugInfo = new DebugInformation(e);            
            if (OnStep != null)
                OnStep(DebugInfo);

            if (PauseOnStep)
                Pause();
        }

        public object Run(string script)
        {
            return engine.Run(script);
        }

        public void RegisterFunction(string name, Delegate function)
        {
            engine.SetFunction(name, function);            
        }

        public void RegisterObject(string name, Object o)
        {
            engine.SetParameter(name, o);
        }

        public void AddBreakpoint(int line, int @char)
        {
            engine.BreakPoints.Add(new Jint.Debugger.BreakPoint(line, @char));
        }

        public void AddBreakpoint(int line, int @char, string condition)
        {
            engine.BreakPoints.Add(new Jint.Debugger.BreakPoint(line, @char,condition));
        }

        public void RemoveBreakpoint(int line, int @char)
        {
            foreach (Jint.Debugger.BreakPoint b in engine.BreakPoints)
            {
                if (b.Line == line && b.Char == @char)
                {
                    engine.BreakPoints.Remove(b);
                    break;
                }
            }
        }        

        public void ClearBreakpoints()
        {
            engine.BreakPoints.Clear();
        }

        public void QueueScript(string script)
        {
            scriptQueue.Enqueue(script);        
        }

        public void ExecuteScripts()
        {
            string script = String.Empty;
            try
            {
                while (scriptQueue.Count > 0)
                {
                    LastException = null;
                    script = scriptQueue.Dequeue();
                    Run(script);
                }
            }
            catch (JintException e)
            {
                if (DebugInfo != null)
                    LastException = new ScriptException(DebugInfo.Line, DebugInfo.Char, DebugInfo.Statement, e);
                else
                    LastException = new ScriptException(0, 0, script.Split(new string[] { Environment.NewLine }, StringSplitOptions.None)[0], e);

                if (engine.DebugMode)
                {
                    Break();
                }
            }           
            finally
            {
                if (OnCompleted != null)
                {
                    OnCompleted(new DebugInformation(Int32.MaxValue, Int32.MaxValue));
                }
            }
        }

        public void ClearExceptions()
        {
            LastException = null;
        }

        public void StopScripts()
        {
            scriptQueue.Clear();
            PauseOnStep = false;
            Resume();
        }
    }
}
