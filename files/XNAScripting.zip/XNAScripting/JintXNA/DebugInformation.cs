﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Jint.Native;

namespace JintXNA
{
    public class DebugInformation
    {
        public int Line { get; private set; }
        public int Char { get; private set; }
        public string Statement { get; private set; }
        public Stack<string> CallStack { get; private set; }
        public Dictionary<string, object> Locals { get; private set; }

        public DebugInformation(Jint.Debugger.DebugInformation nativeInfo)
        {            
            Line = nativeInfo.CurrentStatement.Source.Start.Line;
            Char = nativeInfo.CurrentStatement.Source.Start.Char;
            Statement = nativeInfo.CurrentStatement.Source.Code.Trim();
            CallStack = nativeInfo.CallStack;

            Locals = new Dictionary<string, object>();
            foreach (KeyValuePair<string, JsInstance> pair in nativeInfo.Locals)
            {
                if (pair.Value != null)
                {
                    if (pair.Value.IsClr)
                    {
                        Locals.Add(pair.Key, pair.Value.Value);
                    }
                    else if (!pair.Value.Class.Equals("Function", StringComparison.InvariantCultureIgnoreCase))
                    {
                        Locals.Add(pair.Key, pair.Value.ToString());
                    }
                }
            }
        }

        public DebugInformation(int line, int @char)
        {
            this.Line = line;
            this.Char = @char;
            Statement = "";
            CallStack = new Stack<string>();
            Locals = new Dictionary<string, object>();
        }
    }
}
